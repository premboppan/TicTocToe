package com.example.macstudent.tictactoe;

import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    int player = 1;

    public void dropIn(View view) {
        ImageView Counter = (ImageView) view;
        counter.setTranslation(-1500);
        if (player == 1) {
            counter.setImageResource(R.drawable.yellow);
            player = 2;
        } else {
            counter.setImageResource(R.drawable.red);
            player = 1;

        }

        counter.animate().translationYby(1500).setDuration(300);
    }
    counter.animate().

    translationYby(1500).

    setDuration(300);

}

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
